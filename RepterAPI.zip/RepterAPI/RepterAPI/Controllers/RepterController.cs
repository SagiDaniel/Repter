﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RepterDB.Model;

namespace RepterAPI.Controllers
{
    [ApiController]
    [Route("api/Repter")]
    public class RepterController : Controller
    {
        private JaratContext _context;
        public RepterController(JaratContext context)
        {
            _context = context;
        }

        [HttpGet("Varosok")]
        public List<Varos> Get()
        {
            return _context.Varosok.ToList();
        }

        [HttpGet("Jaratok")]
        public List<Jarat> Get2()
        {
            return _context.Jatatok.Include(x => x.KiinduloVaros).ToList();
        }
    }
}
